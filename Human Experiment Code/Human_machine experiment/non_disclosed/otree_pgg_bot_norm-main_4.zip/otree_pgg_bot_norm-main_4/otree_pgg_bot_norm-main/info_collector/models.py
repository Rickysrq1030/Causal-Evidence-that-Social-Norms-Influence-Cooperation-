from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
from django.forms import Select
from otree.forms import forms

author = 'xxx'

doc = """
Information collector, suggest append to all experiments 
"""

default_conf_in_settings = dict(
    name='info_collector',
    display_name="Information collector",
    num_demo_participants=1,
    app_sequence=['info_collector'],
)


class Constants(BaseConstants):
    name_in_url = 'info_collector'
    players_per_group = None
    num_rounds = 1




class Subsession(BaseSubsession):
    @property
    def en(self):
        return False if 'show_en' not in self.session.config else self.session.config['show_en']


class Group(BaseGroup):
    pass

class Player(BasePlayer):
    # survey
    # 1. 在你参加的活动中，其他参与者的身份是什么
    participant_identity = models.IntegerField(
        choices=[(1, '都是人'),
                 (2, '其中一个是机器人，其他人都是人'),
                 (3, '其中两个是机器人，其他人都是人'),
                 (4, '都是机器人')],
        widget=forms.RadioSelect,
        label='在您参加的活动中，其他参与者的<b>身份</b>是什么'
    )

    # 2. 您认为其他人对公共资金的投资是公平的吗？
    is_other_fair = models.IntegerField(
        choices=[(1, '是'), (2, '否')],
        widget=forms.RadioSelect,
        label='您认为<b>其他人</b>对<span style="color: purple">公共资金</span>的<b>投资</b>是<b>公平</b>的吗？'
    )

    # 3. 在整个活动中，您认为其他人投资与您相似金额的频率是多少
    investment_frequency = models.IntegerField(
        choices=[(1, '总是'),
                 (2, '经常'),
                 (3, '很少'),
                 (4, '从不')],
        widget=forms.RadioSelect,
        label='在整个活动中，您认为<b>其他人投资与您相似金额</b>的频率是多少'
    )

    # 4. 您认为该小组最大化了整体收益吗？
    group_maximized_returns = models.IntegerField(
        choices=[(1, '是'),
                 (2, '否')],
        widget=forms.RadioSelect,
        label='您认为<b>该小组最大化了整体收益</b>吗？'
    )

    # 5. 您是否根据您认为其他人会做的事情改变了您的投资？
    changed_investment_based_on_others = models.IntegerField(
        choices=[(1, '是'),
                 (2, '否')],
        widget=forms.RadioSelect,
        label='您是否根据<b>您认为其他人会做的事情</b>改变了您的投资？'
    )

    # 6. 如果您做出了投资，以下哪项最能描述您决定做出投资或保持的主要原因？
    main_reason_for_investment = models.IntegerField(
        choices=[(1, '最大化我的收入'),
                 (2, '最大化小组的收入'),
                 (3, '确保我的决定与大多数人的决定一致'),
                 (4, '避免被他人利用的感觉')],
        widget=forms.RadioSelect,
        label='如果您做出了投资，以下哪项最能描述您决定做出投资或保持的<b>主要原因</b>？'
    )

    # 7. 您是否觉得您的决定影响了小组的决定？
    decision_influenced_group = models.IntegerField(
        choices=[(1, '是'),
                 (2, '否')],
        widget=forms.RadioSelect,
        label='您是否觉得<b>您的决定</b>影响了<b>小组的决定</b>？'
    )

    # 8. 您是否感到有责任为公共资金投资？
    feel_responsible_for_investment = models.IntegerField(
        choices=[(1, '是'),
                 (2, '否')],
        widget=forms.RadioSelect,
        label='您是否<b>感到有责任</b>为公共资金投资？'
    )

    # 9. 您对小组成员为公共资金捐款有多大信任？
    trust_in_group_contribution = models.IntegerField(
        choices=[(1, '高'),
                 (2, '中等'),
                 (3, '低'),
                 (4, '无')],
        widget=forms.RadioSelect,
        label='您对<b>小组成员</b>为公共资金捐款有多大<b>信任</b>？'
    )

    # persona info
    game_id = models.StringField(blank=False)
    name = models.StringField(blank=False)
    contact = models.StringField(blank=False)
    student_id = models.StringField(blank=True)
    school = models.StringField(blank=False)
    major = models.StringField(blank=False)
    gender = models.StringField(blank=False, widget=Select)
    nation = models.StringField(blank=False)
    age = models.IntegerField(blank=False, min=10, max=100)
    country = models.StringField(blank=False)
    # birthplace = models.StringField(blank=False)
    religion = models.StringField(blank=True)
    alipay = models.StringField(blank=True)

    groups = models.StringField(
        blank=False,
        label="您属于以下哪个群体？您可以选择多个写入。1.白人；2.黑人/非裔美国人；3.西班牙裔/拉丁裔；4.亚裔或亚裔美国人；5.美洲印第安人或阿拉斯加原住民；6.中东人或北非人；7.其他；（填写数字，用‘，’隔开）"
   )

    # 居住地点
    location = models.StringField(
        blank=False,
        label="您目前居住在哪里？"
    )

    # 教育水平
    education_level = models.StringField(
        choices=[
            ('high_school_or_less', '高中以下'),
            ('high_school_equivalent', '高中或同等学历（例如 GED）'),
            ('some_college', '大学以上学历'),
            ('associates_degree', '2 年制学位（副学士）'),
            ('bachelors_degree', '4 年制学位（学士学位）'),
            ('graduate_or_professional', '研究生或专业学位')
        ],
        blank=False,
        label="您完成的最高教育水平是什么？"
    )

    # 家庭税前收入
    income = models.StringField(
        choices=[
            ('under_10000', '少于 10,000 美元'),
            ('10000_to_19999', '10,000 至 19,999 美元'),
            ('20000_to_29999', '20,000 至 29,999 美元'),
            ('30000_to_39999', '30,000 至 39,999 美元'),
            ('40000_to_49999', '40,000 至 49,999 美元'),
            ('50000_to_59999', '50,000 至 59,999 美元'),
            ('60000_to_69999', '60,000 至 69,999 美元'),
            ('70000_to_79999', '70,000 至 79,999 美元'),
            ('80000_to_89999', '80,000 至 89,999 美元'),
            ('90000_to_99999', '90,000 至 99,999 美元'),
            ('100000_to_149999', '100,000 至 149,999 美元'),
            ('150000_or_more', '150,000 美元或以上')
        ],
        blank=False,
        label="2023 年您的家庭税前收入总额是多少？"
    )

    # 就业状况
    employment_status = models.StringField(
        choices=[
            ('full_time', '全职'),
            ('part_time', '兼职'),
            ('temporarily_unemployed', '暂时失业'),
            ('long_term_unemployed', '长期失业')
        ],
        blank=False,
        label="您的就业状况如何？"
    )

    # 如果有工作，工作所属组织类型
    organization_type = models.StringField(
        choices=[
            ('public', '公共'),
            ('private', '私人'),
            ('self_employed', '自雇')
        ],
        blank=True,
        label="如果您目前有工作，您的组织属于哪一类？"
    )

    # 活动反馈
    activity_feedback = models.TextField(
        blank=True,
        label="该活动有什么奇怪或令人惊讶的地方吗？"
    )

  # 问题 1
    cultural_rule_importance = models.IntegerField(
        choices=[(1, '完全不重要'), (2, '不重要'), (3, '不太重要'),
                 (4, '中性'), (5, '比较重要'), (6, '重要'), (7, '非常重要')],
        widget=forms.RadioSelect,
        label="在您的文化中遵守规则和规定有多重要?"
    )

    # 问题 2
    social_norm_reinforcement = models.IntegerField(
        choices=[(1, '完全不强化'), (2, '不强化'), (3, '不怎么强化'),
                 (4, '中性'), (5, '一般强化'), (6, '强化'), (7, '强制强化')],
        widget=forms.RadioSelect,
        label="您认为社会在多大程度上通过一些手段强化社会规范（例如，通过法律、社会压力等方式）?"
    )

    # 问题 3
    breaking_norm_acceptability = models.IntegerField(
        choices=[(1, '完全不接受'), (2, '不接受'), (3, '不太接受'),
                 (4, '中性'), (5, '勉强接受'), (6, '接受'), (7, '完全接受')],
        widget=forms.RadioSelect,
        label="您认为在您的文化中，打破社会规范在多大程度上是可以接受的?"
    )

    # 问题 4
    social_norm_strictness = models.IntegerField(
        choices=[(1, '非常灵活'), (2, '灵活'), (3, '不太灵活'),
                 (4, '中性'), (5, '有点严格'), (6, '严格'), (7, '非常严格')],
        widget=forms.RadioSelect,
        label="在您看来，您所在社区的社会规范有多严格（例如，行为举止、着装、准时等）?"
    )

    # 问题 5
    social_norm_expectation = models.IntegerField(
        choices=[(1, '完全不期望'), (2, '不期望'), (3, '不太期望'),
                 (4, '中性'), (5, '有点期望'), (6, '期望'), (7, '非常强烈的期望')],
        widget=forms.RadioSelect,
        label="您认为在您的文化中，人们对他人遵守社会规范的期望有多强烈？"
    )

    # 问题 6
    punishment_probability = models.IntegerField(
        choices=[(1, '完全不可能'), (2, '不可能'), (3, '不太可能'),
                 (4, '中性'), (5, '有点可能'), (6, '可能'), (7, '极其可能')],
        widget=forms.RadioSelect,
        label="您认为在您的文化中，某人因违反社会规范而受到惩罚或批评的可能性有多大？"
    )

    # 问题 7
    rule_violence_punishment = models.IntegerField(
        choices=[(1, '完全不惩罚'), (2, '不惩罚'), (3, '不太惩罚'),
                 (4, '中性'), (5, '简单惩罚'), (6, '严厉惩罚'), (7, '极其严厉的惩罚')],
        widget=forms.RadioSelect,
        label="在您的文化中，违反社会规则的行为（即使这些规则看起来很小，如迟到、不礼貌）会受到多大程度的惩罚？"
    )

    # 问题 8
    public_norm_expectation = models.IntegerField(
        choices=[(1, '完全不期望'), (2, '不期望'), (3, '不太期望'),
                 (4, '中性'), (5, '有点期望'), (6, '期望'), (7, '非常强烈的期望')],
        widget=forms.RadioSelect,
        label="在您的社区中，人们在公共场合是否期望别人遵守着装规范和行为规范？"
    )

    # 问题 9
    rule_compliance_probability = models.IntegerField(
        choices=[(1, '完全不可能'), (2, '不可能'), (3, '不太可能'),
                 (4, '中性'), (5, '有点可能'), (6, '可能'), (7, '非常可能')],
        widget=forms.RadioSelect,
        label="即使没有人看见或者没有直接后果，您有多大可能遵守规则？"
    )

    # 问题 10
    group_norm_pressure = models.IntegerField(
        choices=[(1, '完全没有压力'), (2, '没有压力'), (3, '基本没压力'),
                 (4, '中性'), (5, '有点压力'), (6, '有压力'), (7, '非常大的压力')],
        widget=forms.RadioSelect,
        label="当您处于群体环境中时，您感受到的遵守社会规范的压力有多强烈？"
    )

    # 问题 11
    individualism_vs_norms = models.IntegerField(
        choices=[(1, '强烈重视社会规范'), (2, '重视社会规范'), (3, '一般重视社会规范'),
                 (4, '中性'), (5, '一般重视个性'), (6, '重视个性'), (7, '非常重视个性')],
        widget=forms.RadioSelect,
        label="您有多重视个性和个人自由，而不是遵守既定的社会规范？"
    )

    # 问题 12
    harmony_importance = models.IntegerField(
        choices=[(1, '完全不重要'), (2, '不重要'), (3, '不太重要'),
                 (4, '中性'), (5, '比较重要'), (6, '重要'), (7, '非常重要')],
        widget=forms.RadioSelect,
        label="在您的文化中，保持与他人和谐、遵守社会期望（例如，通过礼貌、避免冲突）有多重要？"
    )

    # 问题 13
    acceptance_of_nontraditional_ideas = models.IntegerField(
        choices=[(1, '完全不接受'), (2, '不接受'), (3, '不太接受'),
                 (4, '中性'), (5, '勉强接受'), (6, '接受'), (7, '完全接受')],
        widget=forms.RadioSelect,
        label="在您的文化中，人们对非传统思想或行为的接受度有多高？"
    )

    # 问题 14
    tolerance_of_different_opinions = models.IntegerField(
        choices=[(1, '完全不容忍'), (2, '不容忍'), (3, '不太容忍'),
                 (4, '中性'), (5, '比较容忍'), (6, '容忍'), (7, '完全容忍')],
        widget=forms.RadioSelect,
        label="在您的文化中，人们对不同意见和行为的容忍度有多高？"
    )

    # 问题 15
    importance_of_tradition = models.IntegerField(
        choices=[(1, '完全不重要'), (2, '不重要'), (3, '不太重要'),
                 (4, '中性'), (5, '比较重要'), (6, '重要'), (7, '非常重要')],
        widget=forms.RadioSelect,
        label="在您的文化中，维护传统和文化习俗（例如，宗教实践、家庭角色）有多重要？"
    )

    # 问题 16
    acceptance_of_rule_breaking_for_creativity = models.IntegerField(
        choices=[(1, '完全不接受'), (2, '不接受'), (3, '不太接受'),
                 (4, '中性'), (5, '勉强接受'), (6, '接受'), (7, '完全接受')],
        widget=forms.RadioSelect,
        label="在您的文化中，人们对因个人原因或创意而打破规则的行为有多大程度的接受？"
    )