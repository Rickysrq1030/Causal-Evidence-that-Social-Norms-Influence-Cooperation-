import random

from django.http import HttpResponseRedirect
from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class Introduction(Page):
    timeout_seconds = 180

    def is_displayed(self):
        return self.round_number == 1

    def vars_for_template(self):
        return {
            'cost': Constants.cost,
            'multiplier': self.session.config['multiplier'],
            'with_bot': self.session.config['with_bot'],
        }


class IntroductionA(Page):
    timeout_seconds = 180

    def is_displayed(self):
        return self.round_number == 1

    def vars_for_template(self):
        return {
            'cost': Constants.cost,
            'multiplier': self.session.config['multiplier'],
            'a_or_not': self.subsession.a_or_not,
            'allc_or_not': self.subsession.allc_or_not,
            'with_bot': self.session.config['with_bot'],
            'truth_or_not': self.session.config['truth_or_not'],
        }


class IntroductionB(Page):
    timeout_seconds = 180

    def is_displayed(self):
        return self.round_number == 1

    def vars_for_template(self):
        return {
            'cost': Constants.cost,
            'multiplier': self.session.config['multiplier'],
            'a_or_not': self.subsession.a_or_not,
        }


class IntroductionRule(Page):
    timeout_seconds = 180

    def is_displayed(self):
        return self.round_number == 1

    def vars_for_template(self):
        return {
            'cost': Constants.cost,
            'multiplier': self.session.config['multiplier'],
        }


class GameCompTest(Page):
    timeout_seconds = 300

    def is_displayed(self):
        return self.round_number == 1

    def vars_for_template(self):
        return {
            'cost': Constants.cost,
            'multiplier': self.session.config['multiplier'],
        }


class CheckQues(Page):
    timeout_seconds = 300
    form_model = 'player'
    form_fields = ['wrong_answers']

    def is_displayed(self):
        self.player.wrong_answers = 0
        return self.round_number == 1

    def vars_for_template(self):
        return {
            'cost': Constants.cost,
            'multiplier': self.session.config['multiplier'],
        }

    def before_next_page(self):
        # 获取前端传递的 wrong_answers
        wrong_answers = self.player.wrong_answers
        self.player.wrong_answers = wrong_answers


class Contribute(Page):
    form_model = 'player'

    def get_form_fields(self):
        return ['conti_choice'] if self.session.config['continuous_stra'] \
            else ['disc_choice']

    def get_timeout_seconds(self):
        return self.session.config['timeout_seconds']

    def vars_for_template(self):
        return {
            'total_payoff': round(self.player.get_total_payoff() + self.group.count, 3),
            'multiplier': self.session.config['multiplier'],
            'N': self.session.config['players_per_group'] / (1 - self.session.config['bot_proportion']),
            'header_color1': '#c5e0b4',
            'bg_color1': '#e2f0d9',

            'stra_model': 1 if self.session.config['continuous_stra'] else 0,
        }

    def before_next_page(self):
        if self.timeout_happened:
            if self.session.config['continuous_stra']:
                self.player.conti_choice = round(random.random(), 3)
            else:
                self.player.disc_choice = random.randint(0, 1)


class ContributeNew(Page):
    form_model = 'player'

    def get_form_fields(self):
        return ['conti_choice'] if self.session.config['continuous_stra'] \
            else ['disc_choice']

    def get_timeout_seconds(self):
        return self.session.config['timeout_seconds']

    def vars_for_template(self):
        return {
            'total_payoff': round(self.player.get_total_payoff() + self.group.count, 3),
            'multiplier': self.session.config['multiplier'],
            'N': self.session.config['players_per_group'] / (1 - self.session.config['bot_proportion']),
            'with_bot': self.session.config['with_bot'],
            'truth_or_not': self.session.config['truth_or_not'],
            'bot_proportion': self.session.config['bot_proportion'],
            'header_color1': '#c5e0b4',
            'bg_color1': '#e2f0d9',

            'stra_model': 1 if self.session.config['continuous_stra'] else 0,
        }

    def before_next_page(self):
        if self.timeout_happened:
            if self.session.config['continuous_stra']:
                self.player.conti_choice = round(random.random(), 3)
            else:
                self.player.disc_choice = random.randint(0, 1)


class ResultsWaitPage(WaitPage):
    def after_all_players_arrive(self):
        self.subsession.cal_count()  # 在选择都结束时候首先修改count计数
        self.group.play_one_interaction()  # 计算收益
        self.subsession.switch_round()  # 使得下轮的count，current_high_or_low，和survey值等于当前数值
        self.subsession.judge_end()  # 根据num_round判断是否结束


class Results(Page):
    def get_timeout_seconds(self):
        return self.session.config['timeout_seconds']

    def vars_for_template(self):
        return {
            'total_payoff': round(self.player.get_total_payoff() - (
                self.player.norm_payoff if self.subsession.with_norm else 0) + self.group.count, 3),
            'pool_payoff': round(
                self.player.payoff - (self.player.norm_payoff if self.subsession.with_norm else 0), 3),
            'group_num': round(self.session.config['players_per_group'] / (1 - self.session.config['bot_proportion']),
                               3),
            'multiplier': self.session.config['multiplier'],
            'group_contribution_num': self.group.get_group_contribution_num,
            'N': self.session.config['players_per_group'] / (1 - self.session.config['bot_proportion']),
            'header_color1': '#c5e0b4',
            'bg_color1': '#e2f0d9',

            # for debug
            'stra_model': 1 if self.session.config['continuous_stra'] else 0,
            'neighbors': self.group.get_players(),
            'count': self.group.count,
            'round': self.subsession.round if self.group.count != 0 else self.subsession.round - 1,
            'interaction': self.subsession.interaction if self.group.count != 0 else self.subsession.interaction +
                                                                                     self.session.config['judge_round']
        }


class ResultsNew(Page):
    def get_timeout_seconds(self):
        return self.session.config['timeout_seconds']

    def vars_for_template(self):
        return {
            'total_payoff': round(self.player.get_total_payoff() - (
                self.player.norm_payoff if self.subsession.with_norm else 0) + self.group.count - self.group.group_cur_return +(0 if self.player.get_choice() == 1 else -1), 3),
            'pool_payoff': round(
                self.player.payoff - (self.player.norm_payoff if self.subsession.with_norm else 0), 3),
            'group_num': round(self.session.config['players_per_group'] / (1 - self.session.config['bot_proportion']),
                               3),
            'multiplier': self.session.config['multiplier'],
            'group_contribution_num': self.group.get_group_contribution_num,
            'group_contribution_double': self.group.group_cur_return * 10,
            'N': self.session.config['players_per_group'] / (1 - self.session.config['bot_proportion']),
            'with_norm': self.subsession.with_norm,
            'group_cur_return': self.group.group_cur_return,
            'norm_payoff': self.player.norm_payoff if self.subsession.with_norm else 0,
            'header_color1': '#c5e0b4',
            'bg_color1': '#e2f0d9',

            # for debug
            'stra_model': 1 if self.session.config['continuous_stra'] else 0,
            'neighbors': self.group.get_players(),
            'count': self.group.count,
            'round': self.subsession.round if self.group.count != 0 else self.subsession.round - 1,
            'interaction': self.subsession.interaction if self.group.count != 0 else self.subsession.interaction +
                                                                                     self.session.config['judge_round']
        }


class NormResults(Page):
    def is_displayed(self):
        return self.subsession.with_norm

    def get_timeout_seconds(self):
        return self.session.config['timeout_seconds']

    def vars_for_template(self):
        return {
            'norm_payoff': self.player.norm_payoff,
            'total_payoff': round(self.player.get_total_payoff() + self.group.count, 3),
            'multiplier': self.session.config['multiplier'],
            'self_choice': '投资' if self.player.get_choice() == 1 else '不投资',
            'opponent_choice': '投资' if self.player.get_opponent_choice() == 1 else '不投资',
            'is_consistent': True if self.player.is_consistent else False,
            'norm_c': self.session.config['norm_c'],

            # for debug
            'neighbors': str(self.group.get_players()),
            'count': self.group.count,
        }


class FinalResults(Page):
    timeout_seconds = 45

    def is_displayed(self):
        return self.session.vars['end_game']

    def vars_for_template(self):
        return {
            'has_upcoming_apps': len(self.session.config['app_sequence']) > 1
        }

    def app_after_this_page(self, upcoming_apps):
        if self.session.vars['end_game'] and len(upcoming_apps) > 0:
            return upcoming_apps[0]


# page_sequence = [Introduction, Introduction2, GameCompTest, Introduction3, Contribute, ResultsWaitPage, Results, NormResults,  FinalResults]
page_sequence = [Introduction, IntroductionA,IntroductionRule, CheckQues, ContributeNew,
                 ResultsWaitPage, ResultsNew, FinalResults]
