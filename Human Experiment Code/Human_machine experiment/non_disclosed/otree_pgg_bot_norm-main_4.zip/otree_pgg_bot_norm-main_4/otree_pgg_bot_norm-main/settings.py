from os import environ

SESSION_CONFIGS = [
    dict(
        name='pgg_no_survey',
        display_name="Public Goods Game No Survey",
        num_demo_participants=8,
        players_per_group=8,
        init_money=50,
        multiplier=2,
        total_round = 10,
        new_round_probability=0,
        timeout_seconds=40,
        continuous_stra=False,
        USE_POINTS = False,
        show_en = False,

        with_bot=True,
        # allc_or_not=True,
        bot_proportion=0.2,
        
        # with_norm=False,
        norm_c=1.5,

        truth_or_not=True,

        # a_or_not=True,

        # app_sequence=['pgg_no_survey','info_collector_one'，'pgg_no_two','info_collector'],
        app_sequence=['pgg_no_survey', 'info_collector_one','pgg_no_two','info_collector_two', 'pgg_no_three','info_collector_three','pgg_no_four','info_collector'],

    )
]

# if you set a property in SESSION_CONFIG_DEFAULTS, it will be inherited by all configs
# in SESSION_CONFIGS, except those that explicitly override it.
# the session config can be accessed from methods in your apps as self.session.config,
# e.g. self.session.config['participation_fee']

SESSION_CONFIG_DEFAULTS = dict(
    real_world_currency_per_point=1.00, participation_fee=0.00, doc=""
)

# ISO-639 code
# for example: de, fr, ja, ko, zh-hans
LANGUAGE_CODE = 'en'

# e.g. EUR, GBP, CNY, JPY
REAL_WORLD_CURRENCY_CODE = 'USD'
USE_POINTS = True

ADMIN_USERNAME = 'admin'
# for security, best to set admin password in an environment variable
ADMIN_PASSWORD = environ.get('OTREE_ADMIN_PASSWORD')

DEMO_PAGE_INTRO_HTML = """ """

SECRET_KEY = 'vcp&7x@sk4ru#bb+ch1c@67lg73p*#l*l5r(hjfn*g0%x1w1d!'

# if an app is included in SESSION_CONFIGS, you don't need to list it here
INSTALLED_APPS = ['otree']