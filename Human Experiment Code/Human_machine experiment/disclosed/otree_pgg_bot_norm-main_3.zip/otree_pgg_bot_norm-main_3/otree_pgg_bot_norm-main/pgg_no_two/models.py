from celery.worker.strategy import default
from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
)

import random

from requests import session

author = 'Hu Xintao & Li Hao & Sun Jialong & Cao Zhaoheng'

doc = """
PGG with No Survey
"""

default_conf_in_settings = dict(
    name='pgg_no_two',
    display_name="Public Goods Game No Survey",
    num_demo_participants=5,
    players_per_group=5,
    init_money=50,
    multiplier1=4,
    multiplier2=2,
    min_total_interactions=40,
    new_round_probability=0,
    continuous_stra=False,
    timeout_seconds=30,
    judge_round=5,
    app_sequence=['pgg_no_survey', 'pgg_no_two','info_collector'],
    threshold_high_to_low=5,
    threshold_low_to_high=2,
)


class Constants(BaseConstants):
    name_in_url = 'pgg_no_two'
    players_per_group = None
    num_rounds = 20
    cost = 1


class Subsession(BaseSubsession):
    round = models.IntegerField()
    interaction = models.IntegerField()
    with_norm = models.BooleanField(default=False)
    allc_or_not = models.BooleanField(default=False)
    a_or_not = models.BooleanField(default=False)


    def creating_session(self):
        if self.round_number == 1:
            ppg = self.session.config['players_per_group']
            players = self.get_players()
            num_players = len(players)

            if ppg < 1:
                raise ValueError("'players_per_group' must be larger than 1.")
            if len(players) % ppg != 0:
                raise ValueError("'Number of participants' must be a multiple of {} ('players_per_group').".format(ppg))
            self.shuffle_group_matrix()
            self.round = 1
            self.interaction = 1
            self.session.vars['end_game'] = False
            self.init_payoff_history()
            for g in self.get_groups():
                g.count=0
            # self.with_norm = False
            # self.allc_or_not = True
            # self.a_or_not = False

            num_bots = int(
                num_players * self.session.config['bot_proportion'] / (1 - self.session.config['bot_proportion']))
            num_groups=len(self.get_groups())
            group_num_bots=int(num_bots/num_groups)
            self.session.vars['bot_payoff'] = [[] for _ in range(num_groups)] # 为每一个组创建一个列表
            self.session.vars['bot_norm_opponent_id_in_group'] = [[] for _ in range(num_groups)]
            self.session.vars['bot_norm_payoff'] = [[] for _ in range(num_groups)]
            self.session.vars['bot_total_payoff'] = [[] for _ in range(num_groups)]
            for g in self.get_groups():
                g.count=0
                self.session.vars['bot_total_payoff'][g.id_in_subsession-1]=[0]*(group_num_bots)


    def shuffle_group_matrix(self):
        ppg = self.session.config['players_per_group']
        players = self.get_players()
        group_matrix = []
        shuffled_player_id = list(range(1, len(players) + 1))
        random.shuffle(shuffled_player_id)
        for i in range(0, len(players), ppg):
            group_matrix.append(shuffled_player_id[i:i + ppg])
        self.set_group_matrix(group_matrix)

    def switch_round(self):
        if not self.session.vars['end_game']:
            self.init_next_round()

    def init_next_round(self):
        self.in_round(self.round_number + 1).interaction = self.interaction + 1
        self.in_round(self.round_number + 1).round = self.round
        self.in_round(self.round_number + 1).group_like_round(self.round_number)

        groups = self.get_groups()
        for g in groups:
            g.copy_group_attr()

    def judge_end(self):
        if self.round_number == Constants.num_rounds or \
                self.round_number >= self.session.config['total_round']:

            self.session.vars['end_game'] = True


    def init_payoff_history(self):
        players = self.get_players()
        for p in players:
            p.store_payoff()

    def cal_count(self):
        groups = self.get_groups()
        for g in groups:
            g.count+=1





class Group(BaseGroup):
    group_choice = models.StringField()
    count = models.IntegerField()
    
    group_cur_return = models.FloatField() # 本轮本组 池子回馈给玩家的收益
    bots_norm_opponent_id_in_group = models.StringField()
    bots_norm_payoff = models.StringField() # 本轮norm收益
    bots_payoff = models.StringField() # 本轮总收益
    bots_total_payoff = models.StringField() # 本轮为止累积总收益
    group_contribution_num = models.IntegerField() # 投资的人数

    def get_group_contribution_num(self):
        num_players = len(self.get_players())
        num_bots = int(
            num_players * self.session.config['bot_proportion'] / (1 - self.session.config['bot_proportion']))
        return int(self.group_cur_return * (num_bots+self.session.config['players_per_group']) / self.session.config['multiplier'])


    def copy_group_attr(self):
        self.in_round(self.round_number + 1).count = self.count
        players = self.get_players()
        for p in players:
            p.in_round(self.round_number + 1).participant.vars['payoffHistory'] = p.participant.vars['payoffHistory']

    def play_one_interaction(self):
        pool = 0

        players = self.get_players()
        num_players = len(players)

        self.group_choice = ', '.join([str(p.conti_choice) if self.session.config['continuous_stra']
                                    else str(p.disc_choice) for p in players])

        for p in players:
            pool += p.conti_choice \
                if self.session.config['continuous_stra'] \
                else p.disc_choice

        num_bots = int(
            num_players * self.session.config['bot_proportion'] / (1 - self.session.config['bot_proportion']))
        # 存在机器人 实验一
        if self.session.config['with_bot']:
            pool += num_bots if self.subsession.allc_or_not else 0

        pool *= self.session.config['multiplier']    
        
        self.group_cur_return = pool / (num_players + num_bots)

        # 随机配对奖惩 实验二
        group_choice_list = self.group_choice.split(', ')
        if self.session.config['with_bot']:
            group_choice_list.extend(['1'] * num_bots if self.subsession.allc_or_not else ['0'] * num_bots)

        num_contr = 0
        for i in group_choice_list:
            if i=='1':
                num_contr+=1

        for p in players:
            p.payoff = self.group_cur_return - \
                       (p.conti_choice if self.session.config['continuous_stra'] else p.disc_choice)

            if self.subsession.with_norm:
                p.norm_opponent_id_in_group = 1
                # 获取随机数
                if num_contr==5:
                    p.norm_payoff = 1.5
                elif group_choice_list[p.id_in_group - 1]=='1' and num_contr>5:
                    p.norm_payoff = 1.5
                elif group_choice_list[p.id_in_group - 1]=='0' and num_contr<5:
                    p.norm_payoff = 1.5
                else:
                    p.norm_payoff = 0.0
                p.payoff += p.norm_payoff
            p.participant.vars['payoffHistory'].append(round(p.payoff, 3))

        if self.session.config['with_bot']:
            group_id = self.id_in_subsession  # 组号 从1开始
            bot_payoff = self.group_cur_return - 1 if \
                self.subsession.allc_or_not else \
                pool / (num_players + num_bots)
            bots_payoff = []
            bots_norm_opponent_id_in_group = []
            bots_norm_payoff = []
            if self.subsession.with_norm:  # 存在奖惩
                for i in range(num_bots):
                    bot_norm = 0
                    if num_contr == 5:
                        bot_norm = 1.5
                    elif group_choice_list[i + num_players] == '1' and num_contr > 5:
                        bot_norm = 1.5
                    elif group_choice_list[i + num_players] == '0' and num_contr < 5:
                        bot_norm = 1.5
                    else:
                        bot_norm = 0.0
                    bots_payoff.append(bot_norm + bot_payoff)
                    bots_norm_payoff.append(bot_norm)

                self.session.vars['bot_norm_payoff'][group_id - 1].append(self.bots_norm_payoff)
                self.session.vars['bot_payoff'][group_id - 1].append(bots_payoff)
            else:
                bots_payoff = [bot_payoff] * num_bots
                self.session.vars['bot_payoff'][group_id - 1].append(self.bots_payoff)
            self.session.vars['bot_total_payoff'][group_id - 1] = [x + y for x, y in zip(
                self.session.vars['bot_total_payoff'][group_id - 1], bots_payoff)]

            self.bots_total_payoff = str(self.session.vars['bot_total_payoff'])
            self.bots_payoff = str(bots_payoff)
            self.bots_norm_opponent_id_in_group = str(bots_norm_opponent_id_in_group)
            self.bots_norm_payoff = str(bots_norm_payoff)
        if self.count <2:
            self.session.vars['end_game'] = False


    def group_contribution_round(self):
        num_players = len(self.get_players())
        num_bots = int(
            num_players * self.session.config['bot_proportion'] / (1 - self.session.config['bot_proportion']))
        return float(self.group_cur_return*(num_players+num_bots))

    def group_avg_payoff_round(self):
        group_payoff_sum_round = self.group_contribution_round()
        players = self.get_players()
        num_players = len(players)
        for p in players:
            group_payoff_sum_round = group_payoff_sum_round - (
                p.conti_choice if self.session.config['continuous_stra'] else p.disc_choice)
        num_bots = int(num_players * self.session.config['bot_proportion'] / (1 - self.session.config['bot_proportion']))
        if self.session.config['with_bot']:
            group_payoff_sum_round = group_payoff_sum_round - num_bots*(1 if self.subsession.allc_or_not else 0)
        return round(group_payoff_sum_round / (num_players + num_bots),3)

    def group_avg_payoff_stage(self):
        players = self.get_players()
        num_players = len(players)
        payoffSum = 0
        num_bots = int(num_players * self.session.config['bot_proportion'] / (1 - self.session.config['bot_proportion']))

        if (abs(self.count) > 0):
            for p in players:
                payoffSum += sum(p.participant.vars['payoffHistory'][
                                -abs(self.count):]) / abs(self.count)
        else:
            for p in players:
                payoffSum += sum(p.participant.vars['payoffHistory'][
                                - abs(self.session.config['judge_round']):]) / \
                            self.session.config['judge_round']
        num_count = abs(self.count) if abs(self.count) > 0 else abs(self.session.config['judge_round'])  # 轮数
        group_id = self.id_in_subsession  # 组号
        if self.session.config['with_bot']:
            for i in self.session.vars['bot_payoff'][group_id - 1][-num_count:]:
                payoffSum += sum(i) / num_count
        return round(payoffSum,3)


class Player(BasePlayer):
    disc_choice = models.IntegerField(
        choices=[[1, '投资'],[0, '保留']],
        widget=widgets.RadioSelect())
    
    conti_choice = models.FloatField(min=0,max=1,)

    norm_opponent_id_in_group = models.IntegerField()

    norm_payoff = models.FloatField()

    is_consistent = models.IntegerField()

    total_payoff = models.FloatField()

    wrong_answers = models.IntegerField(initial=2)

    def store_payoff(self):
        self.participant.vars['payoffHistory'] = []

    def conti_choice_error_message(self, value):
        if len(str(value).split('.')[-1]) > 3:
            return "最多保留至三位小数."

    def get_choice(self):
        return self.conti_choice if self.session.config['continuous_stra'] else self.disc_choice

    def get_opponent_choice(self):
        num_plays = len(self.group.get_players())
        if self.norm_opponent_id_in_group <= num_plays:
            return self.group.get_players()[self.norm_opponent_id_in_group-1].get_choice()
        else:
            return 1 if self.subsession.allc_or_not else 0

    def get_total_payoff(self):
        total_payoff= 0
        if abs(self.group.count) > 0:
            total_payoff += sum(self.participant.vars['payoffHistory'][
                              - abs(self.group.count):])

        return float(total_payoff)
