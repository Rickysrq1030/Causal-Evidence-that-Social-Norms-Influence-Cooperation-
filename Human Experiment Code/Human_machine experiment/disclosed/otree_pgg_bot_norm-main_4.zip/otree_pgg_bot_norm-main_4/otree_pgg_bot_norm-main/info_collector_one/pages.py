from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


def _get_labels(en):
    return {
        'game_id': '实验编号' + (' (Game ID)' if en else ''),
        'name': '姓名' + (' (Name)' if en else ''),
        'contact': '联系电话' + (' (Phone number)' if en else ''),
        'student_id': '学号' + (' (Student ID)' if en else ''),
        'school': '学校' + (' (School/University)' if en else ''),
        'major': '专业' + (' (Major)' if en else ''),
        'gender': '性别' + (' (Gender)' if en else ''),
        'nation': '民族' + (' (Nationality)' if en else ''),
        'age': '年龄' + (' (Age)' if en else ''),
        'country': '国家' + (' (Country)' if en else ''),
        'religion': '宗教' + (' (Religion)' if en else ''),
        'alipay': '支付宝账号' + (' (Alipay account)' if en else ''),

        # 新添加字段的标签
        'groups': '群体' + (' (Groups)' if en else ''),
        'location': '居住地' + (' (Location)' if en else ''),
        'education_level': '教育水平' + (' (Education level)' if en else ''),
        'income': '家庭税前收入' + (' (Household pre-tax income)' if en else ''),
        'employment_status': '就业状况' + (' (Employment status)' if en else ''),
        'organization_type': '工作单位类型' + (' (Organization type)' if en else ''),
        'activity_feedback': '活动反馈' + (' (Activity feedback)' if en else '')
    }

class SurveyMore(Page):
    form_model = 'player'
    form_fields = [
        'participant_identity',
        'is_other_fair',
        'investment_frequency',
        'group_maximized_returns',
        'changed_investment_based_on_others',
        'main_reason_for_investment',
        'decision_influenced_group',
        'feel_responsible_for_investment',
        'trust_in_group_contribution'
    ]

class SurveyTwo(Page):
    form_model = 'player'
    form_fields = [
        'cultural_rule_importance',
        'social_norm_reinforcement',
        'breaking_norm_acceptability',
        'social_norm_strictness',
        'social_norm_expectation',
        'punishment_probability',
        'rule_violence_punishment',
        'public_norm_expectation',
        'rule_compliance_probability',
        'group_norm_pressure',
        'individualism_vs_norms',
        'harmony_importance',
        'acceptance_of_nontraditional_ideas',
        'tolerance_of_different_opinions',
        'importance_of_tradition',
        'acceptance_of_rule_breaking_for_creativity'
    ]

    def vars_for_template(self):
        return {
            'en': self.subsession.en,
            'collect_info_first': self.session.config.get('collect_info_first', False),
            'total_payoff': self.participant.payoff + self.session.config['total_round'],
            'lbl': _get_labels(self.subsession.en)
        }

class RecordInfoMore(Page):
    form_model = 'player'
    form_fields = [
        'game_id', 'name', 'contact', 'student_id', 'school', 'major',
        'gender', 'nation', 'age', 'country', 'religion', 'alipay',
        'groups', 'location', 'education_level', 'income',
        'employment_status', 'organization_type', 'activity_feedback'
    ]

    def vars_for_template(self):
        return {
            'en': self.subsession.en,
            'collect_info_first': self.session.config.get('collect_info_first', False),
            'total_payoff': self.participant.payoff + self.session.config['total_round'],
            'lbl': _get_labels(self.subsession.en)
        }

    def gender_choices(self):
        return [
            ['male', '男' + (' (Male)' if self.subsession.en else '')],
            ['female', '女' + (' (Female)' if self.subsession.en else '')],
            ['others', '其他' + (' (Others)' if self.subsession.en else '')],
        ]


class RecordCompleteMore(Page):
    def vars_for_template(self):
        return {
            'en': self.subsession.en,
            'lbl': _get_labels(self.subsession.en),
            'collect_info_first': self.session.config.get('collect_info_first', False),
            'gender': {'male': '男' + (' (Male)' if self.subsession.en else ''),
                       'female': '女' + (' (Female)' if self.subsession.en else ''),
                       'others': '其他' + (' (Others)' if self.subsession.en else ''),
                       }[self.player.gender]
        }


page_sequence = [
    SurveyMore,
]
